/*==============================================================*/
/* DBMS name:      MySQL 5.0                                    */
/* Created on:     4/10/2022 12:56:49 AM                        */
/*==============================================================*/


drop table if exists ADRESA;

drop table if exists AKREDITACIJA;

drop table if exists CAS;

drop table if exists CLAN;

drop table if exists GODINA;

drop table if exists GRUPA;

drop table if exists ISPIT;

drop table if exists JEZIK;

drop table if exists KONKRETAN_ISPIT;

drop table if exists KONKRETAN_KURS;

drop table if exists KURS;

drop table if exists NIVO;

drop table if exists POLAGAC;

drop table if exists POLAZNIK;

drop table if exists POPUST;

drop table if exists PROFESOR;

drop table if exists SEZONA;

drop table if exists TERMIN;

drop table if exists TIP_GRUPE;

drop table if exists UCIONICA;

drop table if exists UPLATA;

drop table if exists UPLATA_ZA_ISPIT;

drop table if exists UTISAK;

drop table if exists ZOOM_UCIONICA;

/*==============================================================*/
/* Table: ADRESA                                                */
/*==============================================================*/
create table ADRESA
(
   LOKACIJA_ID          varchar(5) not null,
   ADRESA               varchar(100),
   primary key (LOKACIJA_ID)
);

/*==============================================================*/
/* Table: AKREDITACIJA                                          */
/*==============================================================*/
create table AKREDITACIJA
(
   AKREDITACIJA_ID      varchar(5) not null,
   OPIS_AKREDITACIJE    varchar(100),
   primary key (AKREDITACIJA_ID)
);

/*==============================================================*/
/* Table: CAS                                                   */
/*==============================================================*/
create table CAS
(
   CAS_ID               varchar(5) not null,
   LINK                 varchar(50),
   TERMIN_ID            varchar(5) not null,
   GRUPA_ID             varchar(5) not null,
   LOKACIJA_ID          varchar(5) not null,
   UCIONICA_ID          varchar(5) not null,
   PROFESOR_ID          varchar(5) not null,
   DATUM                date,
   primary key (CAS_ID)
);

/*==============================================================*/
/* Table: CLAN                                                  */
/*==============================================================*/
create table CLAN
(
   KORISNIK_ID          varchar(5) not null,
   GRUPA_ID             varchar(5) not null,
   UTISAK_ID            varchar(10),
   primary key (KORISNIK_ID, GRUPA_ID)
);

/*==============================================================*/
/* Table: GODINA                                                */
/*==============================================================*/
create table GODINA
(
   GODINA_ID            numeric(4,0) not null,
   primary key (GODINA_ID)
);

/*==============================================================*/
/* Table: GRUPA                                                 */
/*==============================================================*/
create table GRUPA
(
   GRUPA_ID             varchar(5) not null,
   JEZIK                varchar(10) not null,
   NIVO                 varchar(5) not null,
   KURS_ID              varchar(5) not null,
   GODINA_ID            numeric(4,0) not null,
   SEZ_ID               varchar(5) not null,
   KON_KURS_ID          varchar(5) not null,
   PROFESOR_ID          varchar(5) not null,
   TIP_GRUPE_ID         varchar(5) not null,
   BROJ_DJAKA           numeric(35,0),
   primary key (GRUPA_ID)
);

/*==============================================================*/
/* Table: ISPIT                                                 */
/*==============================================================*/
create table ISPIT
(
   ISPIT_ID             varchar(10) not null,
   JEZIK                varchar(10) not null,
   NIVO                 varchar(5) not null,
   DIPLOMA              varchar(20) not null,
   primary key (ISPIT_ID)
);

/*==============================================================*/
/* Table: JEZIK                                                 */
/*==============================================================*/
create table JEZIK
(
   JEZIK                varchar(10) not null,
   primary key (JEZIK)
);

/*==============================================================*/
/* Table: KONKRETAN_ISPIT                                       */
/*==============================================================*/
create table KONKRETAN_ISPIT
(
   ISPIT_ID             varchar(10) not null,
   GODINA_ID            numeric(4,0) not null,
   SEZ_ID               varchar(5) not null,
   KON_ISPIT_ID         varchar(5) not null,
   LOKACIJA_ID          varchar(5) not null,
   UCIONICA_ID          varchar(5) not null,
   TERMIN_ID            varchar(5) not null,
   PROFESOR_ID          varchar(5) not null,
   CENA_ISPITA          decimal not null,
   primary key (ISPIT_ID, GODINA_ID, SEZ_ID, KON_ISPIT_ID)
);

/*==============================================================*/
/* Table: KONKRETAN_KURS                                        */
/*==============================================================*/
create table KONKRETAN_KURS
(
   JEZIK                varchar(10) not null,
   NIVO                 varchar(5) not null,
   KURS_ID              varchar(5) not null,
   GODINA_ID            numeric(4,0) not null,
   SEZ_ID               varchar(5) not null,
   KON_KURS_ID          varchar(5) not null,
   IZNOS                decimal not null,
   primary key (JEZIK, NIVO, KURS_ID, GODINA_ID, SEZ_ID, KON_KURS_ID)
);

/*==============================================================*/
/* Table: KURS                                                  */
/*==============================================================*/
create table KURS
(
   JEZIK                varchar(10) not null,
   NIVO                 varchar(5) not null,
   KURS_ID              varchar(5) not null,
   AKREDITACIJA_ID      varchar(5),
   NAZIV_KURSA          text not null,
   primary key (JEZIK, NIVO, KURS_ID)
);

/*==============================================================*/
/* Table: NIVO                                                  */
/*==============================================================*/
create table NIVO
(
   NIVO                 varchar(5) not null,
   primary key (NIVO)
);

/*==============================================================*/
/* Table: POLAGAC                                               */
/*==============================================================*/
create table POLAGAC
(
   KORISNIK_ID          varchar(5) not null,
   ISPIT_ID             varchar(10) not null,
   GODINA_ID            numeric(4,0) not null,
   SEZ_ID               varchar(5) not null,
   KON_ISPIT_ID         varchar(5) not null,
   POLAGACC_ID          varchar(5) not null,
   POLOZIO              bool,
   primary key (ISPIT_ID, GODINA_ID, SEZ_ID, KORISNIK_ID, KON_ISPIT_ID, POLAGACC_ID)
);

/*==============================================================*/
/* Table: POLAZNIK                                              */
/*==============================================================*/
create table POLAZNIK
(
   KORISNIK_ID          varchar(5) not null,
   SIFRA_POPUSTA        varchar(10),
   IME_KORISNIKA        varchar(20) not null,
   PREZIME_KORISNIKA    varchar(20) not null,
   GODISTE              numeric(4,0),
   primary key (KORISNIK_ID)
);

/*==============================================================*/
/* Table: POPUST                                                */
/*==============================================================*/
create table POPUST
(
   SIFRA_POPUSTA        varchar(10) not null,
   PROCENAT             numeric(8,0) not null,
   TIP_POPUSTA          text not null,
   primary key (SIFRA_POPUSTA)
);

/*==============================================================*/
/* Table: PROFESOR                                              */
/*==============================================================*/
create table PROFESOR
(
   PROFESOR_ID          varchar(5) not null,
   JEZIK                varchar(10) not null,
   IME_PROFESORA        text not null,
   PREZIME_PROFESORA    text not null,
   primary key (PROFESOR_ID)
);

/*==============================================================*/
/* Table: SEZONA                                                */
/*==============================================================*/
create table SEZONA
(
   SEZ_ID               varchar(5) not null,
   primary key (SEZ_ID)
);

/*==============================================================*/
/* Table: TERMIN                                                */
/*==============================================================*/
create table TERMIN
(
   TERMIN_ID            varchar(5) not null,
   POCETAK              time not null,
   KRAJ                 time not null,
   DAN                  varchar(10),
   primary key (TERMIN_ID)
);

/*==============================================================*/
/* Table: TIP_GRUPE                                             */
/*==============================================================*/
create table TIP_GRUPE
(
   TIP_GRUPE_ID         varchar(5) not null,
   UZRAST               text,
   INDIVIDUALNA         bool not null,
   TIP_GURPE            text not null,
   primary key (TIP_GRUPE_ID)
);

/*==============================================================*/
/* Table: UCIONICA                                              */
/*==============================================================*/
create table UCIONICA
(
   LOKACIJA_ID          varchar(5) not null,
   UCIONICA_ID          varchar(5) not null,
   primary key (LOKACIJA_ID, UCIONICA_ID)
);

/*==============================================================*/
/* Table: UPLATA                                                */
/*==============================================================*/
create table UPLATA
(
   JEZIK                varchar(10) not null,
   NIVO                 varchar(5) not null,
   KURS_ID              varchar(5) not null,
   GODINA_ID            numeric(4,0) not null,
   SEZ_ID               varchar(5) not null,
   KON_KURS_ID          varchar(5) not null,
   KORISNIK_ID          varchar(5) not null,
   SIFRA_UPLATE         numeric(8,0) not null,
   RATA                 numeric(8,0),
   IZNOS                decimal,
   DATUM_UPLATE_KURSA   date,
   primary key (JEZIK, NIVO, KURS_ID, GODINA_ID, SEZ_ID, KON_KURS_ID, KORISNIK_ID, SIFRA_UPLATE)
);

/*==============================================================*/
/* Table: UPLATA_ZA_ISPIT                                       */
/*==============================================================*/
create table UPLATA_ZA_ISPIT
(
   ISPIT_ID             varchar(10) not null,
   GODINA_ID            numeric(4,0) not null,
   SEZ_ID               varchar(5) not null,
   KON_ISPIT_ID         varchar(5) not null,
   KORISNIK_ID          varchar(5) not null,
   SIFRA_UPLATE_ISPITA  numeric(8,0) not null,
   IZNOS                decimal not null,
   DATUM_UPLATE_ISPITA  date,
   primary key (ISPIT_ID, GODINA_ID, SEZ_ID, KON_ISPIT_ID, KORISNIK_ID, SIFRA_UPLATE_ISPITA)
);

/*==============================================================*/
/* Table: UTISAK                                                */
/*==============================================================*/
create table UTISAK
(
   UTISAK_ID            varchar(10) not null,
   KORISNIK_ID          varchar(5) not null,
   GRUPA_ID             varchar(5) not null,
   OPIS_UTISKA          varchar(100),
   OCENA                numeric(1,0),
   primary key (UTISAK_ID)
);

/*==============================================================*/
/* Table: ZOOM_UCIONICA                                         */
/*==============================================================*/
create table ZOOM_UCIONICA
(
   LINK                 varchar(50) not null,
   primary key (LINK)
);

alter table CAS add constraint FK_KONKRETAN_CAS foreign key (GRUPA_ID)
      references GRUPA (GRUPA_ID) on delete restrict on update restrict;

alter table CAS add constraint FK_LINK_ZA_ONLINE_CAS foreign key (LINK)
      references ZOOM_UCIONICA (LINK) on delete restrict on update restrict;

alter table CAS add constraint FK_MESTO_ODRZAVANJA_CASA foreign key (LOKACIJA_ID, UCIONICA_ID)
      references UCIONICA (LOKACIJA_ID, UCIONICA_ID) on delete restrict on update restrict;

alter table CAS add constraint FK_PROFESOR_KOJI_DRZI_CAS foreign key (PROFESOR_ID)
      references PROFESOR (PROFESOR_ID) on delete restrict on update restrict;

alter table CAS add constraint FK_TERMIN_CAS foreign key (TERMIN_ID)
      references TERMIN (TERMIN_ID) on delete restrict on update restrict;

alter table CLAN add constraint FK_POLAZNIK_GRUPE foreign key (KORISNIK_ID)
      references POLAZNIK (KORISNIK_ID) on delete restrict on update restrict;

alter table CLAN add constraint FK_POLAZNIK_GRUPE_2 foreign key (GRUPA_ID)
      references GRUPA (GRUPA_ID) on delete restrict on update restrict;

alter table CLAN add constraint FK_UTISAK_O_KURSU foreign key (UTISAK_ID)
      references UTISAK (UTISAK_ID) on delete restrict on update restrict;

alter table GRUPA add constraint FK_GRUPA_NA_KURSU foreign key (JEZIK, NIVO, KURS_ID, GODINA_ID, SEZ_ID, KON_KURS_ID)
      references KONKRETAN_KURS (JEZIK, NIVO, KURS_ID, GODINA_ID, SEZ_ID, KON_KURS_ID) on delete restrict on update restrict;

alter table GRUPA add constraint FK_PROFESOR_GRUPE foreign key (PROFESOR_ID)
      references PROFESOR (PROFESOR_ID) on delete restrict on update restrict;

alter table GRUPA add constraint FK_TIP_GRUPE foreign key (TIP_GRUPE_ID)
      references TIP_GRUPE (TIP_GRUPE_ID) on delete restrict on update restrict;

alter table ISPIT add constraint FK_JEZIK_POLAGANJA foreign key (JEZIK)
      references JEZIK (JEZIK) on delete restrict on update restrict;

alter table ISPIT add constraint FK_NIVO_KOJI_SE_POLAZE foreign key (NIVO)
      references NIVO (NIVO) on delete restrict on update restrict;

alter table KONKRETAN_ISPIT add constraint FK_CENA_ISPITA foreign key (ISPIT_ID)
      references ISPIT (ISPIT_ID) on delete restrict on update restrict;

alter table KONKRETAN_ISPIT add constraint FK_DEZURNI_PROFESOR foreign key (PROFESOR_ID)
      references PROFESOR (PROFESOR_ID) on delete restrict on update restrict;

alter table KONKRETAN_ISPIT add constraint FK_GODINA_ISPITA foreign key (GODINA_ID)
      references GODINA (GODINA_ID) on delete restrict on update restrict;

alter table KONKRETAN_ISPIT add constraint FK_SEZONA_ISPITA foreign key (SEZ_ID)
      references SEZONA (SEZ_ID) on delete restrict on update restrict;

alter table KONKRETAN_ISPIT add constraint FK_TERMIN_ISPITA foreign key (TERMIN_ID)
      references TERMIN (TERMIN_ID) on delete restrict on update restrict;

alter table KONKRETAN_ISPIT add constraint FK_UCIONICA_U_KOJOJ_SE_ODRZAVA_ISPIT foreign key (LOKACIJA_ID, UCIONICA_ID)
      references UCIONICA (LOKACIJA_ID, UCIONICA_ID) on delete restrict on update restrict;

alter table KONKRETAN_KURS add constraint FK_GODINA_KURSA foreign key (GODINA_ID)
      references GODINA (GODINA_ID) on delete restrict on update restrict;

alter table KONKRETAN_KURS add constraint FK_KONKRETAN_KURS foreign key (JEZIK, NIVO, KURS_ID)
      references KURS (JEZIK, NIVO, KURS_ID) on delete restrict on update restrict;

alter table KONKRETAN_KURS add constraint FK_SEZONA_KURSA foreign key (SEZ_ID)
      references SEZONA (SEZ_ID) on delete restrict on update restrict;

alter table KURS add constraint FK_AKREDITAIJA_KURSA foreign key (AKREDITACIJA_ID)
      references AKREDITACIJA (AKREDITACIJA_ID) on delete restrict on update restrict;

alter table KURS add constraint FK_JEZIK_KURSA foreign key (JEZIK)
      references JEZIK (JEZIK) on delete restrict on update restrict;

alter table KURS add constraint FK_NIVO_KURSA foreign key (NIVO)
      references NIVO (NIVO) on delete restrict on update restrict;

alter table POLAGAC add constraint FK_KORISNIK_JE_POLAGAC foreign key (KORISNIK_ID)
      references POLAZNIK (KORISNIK_ID) on delete restrict on update restrict;

alter table POLAGAC add constraint FK_POLAGAC_KONKRETNOG_ISPITA foreign key (ISPIT_ID, GODINA_ID, SEZ_ID, KON_ISPIT_ID)
      references KONKRETAN_ISPIT (ISPIT_ID, GODINA_ID, SEZ_ID, KON_ISPIT_ID) on delete restrict on update restrict;

alter table POLAZNIK add constraint FK_POPUST foreign key (SIFRA_POPUSTA)
      references POPUST (SIFRA_POPUSTA) on delete restrict on update restrict;

alter table PROFESOR add constraint FK_JEZIK_PROFESORA foreign key (JEZIK)
      references JEZIK (JEZIK) on delete restrict on update restrict;

alter table UCIONICA add constraint FK_LOKACIJA_UCIONICE foreign key (LOKACIJA_ID)
      references ADRESA (LOKACIJA_ID) on delete restrict on update restrict;

alter table UPLATA add constraint FK_UPLATA_POLAZNIKA_ZA_KURS foreign key (KORISNIK_ID)
      references POLAZNIK (KORISNIK_ID) on delete restrict on update restrict;

alter table UPLATA add constraint FK_UPLATA_ZA_KURS foreign key (JEZIK, NIVO, KURS_ID, GODINA_ID, SEZ_ID, KON_KURS_ID)
      references KONKRETAN_KURS (JEZIK, NIVO, KURS_ID, GODINA_ID, SEZ_ID, KON_KURS_ID) on delete restrict on update restrict;

alter table UPLATA_ZA_ISPIT add constraint FK_UPLATA_ZA_ISPIT foreign key (ISPIT_ID, GODINA_ID, SEZ_ID, KON_ISPIT_ID)
      references KONKRETAN_ISPIT (ISPIT_ID, GODINA_ID, SEZ_ID, KON_ISPIT_ID) on delete restrict on update restrict;

alter table UPLATA_ZA_ISPIT add constraint FK_UPLATILAC_ZA_ISPIT foreign key (KORISNIK_ID)
      references POLAZNIK (KORISNIK_ID) on delete restrict on update restrict;

alter table UTISAK add constraint FK_UTISAK_O_KURSU2 foreign key (KORISNIK_ID, GRUPA_ID)
      references CLAN (KORISNIK_ID, GRUPA_ID) on delete restrict on update restrict;

